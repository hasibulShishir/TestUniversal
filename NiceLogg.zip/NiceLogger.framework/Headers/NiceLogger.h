//
//  NiceLogger.h
//  NiceLogger
//
//  Created by Hasibul Hasan Shishir on 10/20/19.
//  Copyright © 2019 Hasibul Hasan Shishir. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for NiceLogger.
FOUNDATION_EXPORT double NiceLoggerVersionNumber;

//! Project version string for NiceLogger.
FOUNDATION_EXPORT const unsigned char NiceLoggerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NiceLogger/PublicHeader.h>


