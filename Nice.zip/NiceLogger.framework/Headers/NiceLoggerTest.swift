//
//  NiceLogger.swift
//  NiceLogger
//
//  Created by Hasibul Hasan Shishir on 10/20/19.
//  Copyright © 2019 Hasibul Hasan Shishir. All rights reserved.
//

import Foundation

public class NiceLoggerTest {
    public init() {}
    
    public func testLogger(name: String) {
        print(name)
    }
}
